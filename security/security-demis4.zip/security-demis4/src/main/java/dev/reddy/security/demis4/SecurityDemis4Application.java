package dev.reddy.security.demis4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityDemis4Application {

	public static void main(String[] args) {
		SpringApplication.run(SecurityDemis4Application.class, args);
	}

}
